FILESEXTRAPATHS:prepend := "${THISDIR}/files:"
SRCREV = "823895ba708c63f6ae4dcbfc266210f26c02c698"
PV = "1.9.8"
SRC_URI:remove = "file://0001-configure-Prune-PIE-flags.patch file://glibc238.patch"
